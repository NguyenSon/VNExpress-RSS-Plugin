<?php
 /*
 Plugin Name: VNExpress RSS plugin
 Plugin URI: misopaladin.wordpress.com
 Description: RSS Feed
 Version: 1.0
 Author: gmmiso88
 Author URI: misopaladin.wordpress.com
 Licence: GPL2
 */
/*  Copyright 2012  Son Nguyen  (email : gmmiso88@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
/**
 * The Plugin Class
 */
if (!class_exists("ms_plugin_template_class")) {
        class ms_plugin_template_class {
            var $rss_links = array();
            // TODO: Variable declarations go here
            // TODO: Constructor                    
            function __construct()
            {
                // TODO: Enter Plugin Actions and Filters here
                $this->rss_links = array(
                    array(                 
                        'id' => 1,
                        'link' => 'http://vnexpress.net/rss/gl/trang-chu.rss',
                        'name' => 'Trang chủ',                        
                    ),
                    array(
                        'id' => 2,
                        'link' => 'http://vnexpress.net/rss/gl/xa-hoi.rss',
                        'name' => 'Xã hội',                        
                    ),
                    array(
                        'id' => 3,
                        'link' => 'http://vnexpress.net/rss/gl/the-gioi.rss',
                        'name' => 'Thế giới',
                    )
                );
                        
                // add settings menu for this plugin
                add_action('admin_menu', array(&$this, 'vnexpress_rss_plugin_menu'),1);
                // short tag for [vnexpress]
                add_filter('the_content', array($this,'vnexpress_short_tag'),1);                                
            }
            // End constructor

            // Core functions go here            
            
            function vnexpress_short_tag($content)
            {
                $search = "[vnexpress]";
                get_settings('vnexpress-rss-settings-group');    
                $links = array(
                    array(                 
                        'id' => 1,
                        'link' => 'http://vnexpress.net/rss/gl/trang-chu.rss',
                        'name' => 'Trang chủ',                        
                    ),
                    array(
                        'id' => 2,
                        'link' => 'http://vnexpress.net/rss/gl/xa-hoi.rss',
                        'name' => 'Xã hội',                        
                    ),
                    array(
                        'id' => 3,
                        'link' => 'http://vnexpress.net/rss/gl/the-gioi.rss',
                        'name' => 'Thế giới',
                    )
                );
                $replace = "";
                for($i=0; $i < count($links); $i++)
                {
                    if( $links[$i]['id'] == get_option('opt_select') )
                    {
                        // lay du lieu tu rss
                        $dom=new DOMDocument('1.0','utf-8');//tao doi tuong dom 
                            $dom->load($links[$i]['link'])    ;//muon lay rss tu trang nao thi ban khai bao day
                            $items = $dom->getElementsByTagName("item");//lay cac element co tag name la item va gan vao bien $items 
                            foreach($items as $item)//lap 
                            { 
                                $titles=$item->getElementsByTagName('title');//lay cac element co tag name la title va gan vao bien $titles                     
                                $title=$titles->item(0);//lay ra gia tri dau tuien trong array $titles                     
                                $descriptions=$item->getElementsByTagName('description'); 
                                $des=$descriptions->item(0); 

                                $links=$dom->getElementsByTagName('link'); 
                                $link=$links->item(0); 

                        $replace .="
                        <table width=\"90%\" border=\"1\">
                          <tr> 
                            <td style=\"color:#FF0000; font-weight:bold; text-decoration:none\">
                            <a href=\"{$link->nodeValue}\" />{$title->nodeValue}</td> 
                          </tr> 
                          <tr> 
                            <td>{$des->nodeValue}</td> 
                          </tr> 
                        </table>";
                         }             
                        break;
                    }
                }
                $content = str_replace($search, $replace, $content);
                return $content;
            }          
            
            function vnexpress_rss_plugin_menu() {
                // Does the user have the right permissions?
                if (!current_user_can('manage_options')) {
                         wp_die( __('Sorry, you do not have permission to access this page.'));
                }
                // User has permission to modify data.
                //add_menu_page('RSS VNExpress Plugin Settings', 'RSS VNExpress Plugin Settings', 'administrator', 'vnexpress-rss-setting' , array(&$this,'vnexpress_plugin_settings_page'),plugins_url('/images/icon.png', __FILE__));                
                    add_options_page('RSS Plugin Options',  // Page title
                            'RSS VNExpress Plugin Settings',  // Menu title
                            'manage_options',  // The Capability requirements
                            'vnexpress-rss-plugin',  // Unique menu slug
                            array(&$this, 'vnexpress_plugin_settings_page'));  // Function call                
                add_action( 'admin_init', array(&$this,'vnexpress_rss_register_settings') );
            }
            
            function vnexpress_plugin_settings_page() {
                
                $links = $this->rss_links;
            ?>
            <div class="wrap">
            <h2>VNExpress RSS Settings</h2>

            <form method="post" action="options.php">
                <?php settings_fields( 'vnexpress-rss-settings-group' ); ?>
                <?php do_settings_fields('vnexpress-rss-settings-group' ,'vnexpress-rss-settings-group' ); ?>
                <table class="form-table">
                    <tr valign="top">
                    <th scope="row">Select your rss link</th>
                    <td>
                        <select name="opt_select">
                           <?php foreach($links as $link) : ?>
                            <option <?php if($link['id'] == get_option('opt_select')) echo 'selected="selected"'; ?> 
                                value="<?php echo $link['id']; ?>">
                                <?php echo $link['name']; ?>
                            </option>
                           <?php endforeach; ?>
                        </select>                        
                    </td>
                    </tr>
                </table>

                <p class="submit">
                <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
                </p>

            </form>
            </div>
            <?php }                        
            function vnexpress_rss_register_settings()
            {
                //register our settings
                register_setting( 'vnexpress-rss-settings-group', 'opt_select' );
                echo get_option('opt_select');
            }            
            
            // widget show
            
            // TODO: Enter Action and Filter Methods here
            
            // TODO: Enter Helper Methods here                    
            
        }// end demo_plugin_template_class								
} // End if (!class_exists("demo_plugin_template_class"))

/**
 * Instantiate (create an instance of) the class
 */
if (class_exists("ms_plugin_template_class")) {    
	// TODO: Enter New Instance Name
	$demo_plugin = new ms_plugin_template_class();
} // End instantiate class
 
class VNExpressRSSWidget extends WP_Widget
{
  function VNExpressRSSWidget()
  {
    $widget_ops = array('classname' => 'VNExpressRSS', 'description' => 'Displays VNExpress RSS' );
    $this->WP_Widget('VNExpressRSSWidget', 'VNExpressRSS', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
    $title = $instance['title'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
 
    if (!empty($title))
      echo $before_title . $title . $after_title;;
 
    // WIDGET CODE GOES HERE        
    get_settings('vnexpress-rss-settings-group');    
    $links = array(
                    array(                 
                        'id' => 1,
                        'link' => 'http://vnexpress.net/rss/gl/trang-chu.rss',
                        'name' => 'Trang chủ',                        
                    ),
                    array(
                        'id' => 2,
                        'link' => 'http://vnexpress.net/rss/gl/xa-hoi.rss',
                        'name' => 'Xã hội',                        
                    ),
                    array(
                        'id' => 3,
                        'link' => 'http://vnexpress.net/rss/gl/the-gioi.rss',
                        'name' => 'Thế giới',
                    )
                );
    for($i=0; $i < count($links); $i++)
    {
        if( $links[$i]['id'] == get_option('opt_select') )
        {
            // lay du lieu tu rss
            $dom=new DOMDocument('1.0','utf-8');//tao doi tuong dom 
                $dom->load($links[$i]['link'])    ;//muon lay rss tu trang nao thi ban khai bao day
                $items = $dom->getElementsByTagName("item");//lay cac element co tag name la item va gan vao bien $items 
                foreach($items as $item)//lap 
                { 
                    $titles=$item->getElementsByTagName('title');//lay cac element co tag name la title va gan vao bien $titles                     
                    $title=$titles->item(0);//lay ra gia tri dau tuien trong array $titles                     
                    $descriptions=$item->getElementsByTagName('description'); 
                    $des=$descriptions->item(0); 

                    $links=$dom->getElementsByTagName('link'); 
                    $link=$links->item(0); 

            ?>
            <table width="90%" border="1">
              <tr> 
                <td style="color:#FF0000; font-weight:bold; text-decoration:none"><a href="<?  echo $link->nodeValue ;?>" /><? echo $title->nodeValue ?></td> 
              </tr> 
              <tr> 
                <td><? echo $des->nodeValue ?></td> 
              </tr> 
            </table> 
             <? 
             }             
            break;
        }
    }
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("VNExpressRSSWidget");') );
?>